<template>
  <div>
    <NavBar />
    <div class="stats-page">
      <h1>Statistics</h1>
      <div class="charts-container">
        <div class="chart-container">
          <canvas v-if="hasLibrarianStats" id="librarianStatsChart"></canvas>
          <div v-else class="no-data-message">
            <p>No books have been issued yet.</p>
          </div>
        </div>
        <div class="chart-container">
          <canvas v-if="hasSectionBooksData" id="sectionBooksChart"></canvas>
          <div v-else class="no-data-message">
            <p>No section books data available.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);
import NavBar from "./Navbar.vue";
import apiService from "@/services/apiService";

export default {
  name: "LibStats",
  components: {
    NavBar,
  },
  data() {
    return {
      stats: {},
      sectionBooksData: {},
    };
  },
  computed: {
    hasLibrarianStats() {
      return Object.keys(this.stats).length > 0;
    },
    hasSectionBooksData() {
      return Object.keys(this.sectionBooksData).length > 0;
    },
  },
  mounted() {
    this.fetchLibrarianStats();
    this.fetchSectionBooksData();
  },
  methods: {
    async fetchLibrarianStats() {
      try {
        const response = await apiService.get("/library/getIssuedBooks/admin", {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.stats = response.data;
        if (this.hasLibrarianStats) {
          this.$nextTick(() => {
            this.createLibrarianStatsChart();
          });
        }
      } catch (error) {
        console.error("Error fetching librarian stats:", error);
      }
    },
    async fetchSectionBooksData() {
      try {
        const response = await apiService.get("/library/getSectionBooks/admin", {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.sectionBooksData = response.data;
        if (this.hasSectionBooksData) {
          this.$nextTick(() => {
            this.createSectionBooksChart();
          });
        }
      } catch (error) {
        console.error("Error fetching section books data:", error);
      }
    },
    createLibrarianStatsChart() {
      const ctx = document.getElementById("librarianStatsChart");
      new Chart(ctx, {
        type: "bar",
        data: {
          labels: Object.keys(this.stats),
          datasets: [
            {
              label: "Count",
              data: Object.values(this.stats),
              backgroundColor: "rgba(75, 192, 192, 0.6)",
              borderColor: "rgba(75, 192, 192, 1)",
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Books issued section-wise' }
          },
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    },
    createSectionBooksChart() {
      const ctx = document.getElementById("sectionBooksChart");
      new Chart(ctx, {
        type: "pie",
        data: {
          labels: Object.keys(this.sectionBooksData),
          datasets: [{
            data: Object.values(this.sectionBooksData),
            backgroundColor: [
              'rgba(255, 99, 132, 0.6)',
              'rgba(54, 162, 235, 0.6)',
              'rgba(255, 206, 86, 0.6)',
              'rgba(75, 192, 192, 0.6)',
              'rgba(153, 102, 255, 0.6)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
            ],
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Books Distribution by Section' }
          }
        }
      });
    },
  },
};
</script>

<style scoped>
.stats-page {
  font-family: 'Times New Roman', Times, serif;
  padding: 40px;
  max-width: 1200px;
  margin: 0 auto;
}

h1 {
  font-size: 2.5rem;
  color: #333;
  margin-bottom: 30px;
  text-align: center;
}

.charts-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  gap: 30px;
}

.chart-container {
  flex: 1 1 calc(50% - 15px);
  min-width: 300px;
  height: 400px;
  background-color: #ffffff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  display: flex;
  align-items: center;
  justify-content: center;
}

.chart-container canvas {
  width: 100% !important;
  height: 100% !important;
}

.no-data-message {
  text-align: center;
  font-size: 1.2rem;
  color: #666;
}

@media (max-width: 768px) {
  .stats-page {
    padding: 20px;
  }

  h1 {
    font-size: 2rem;
  }

  .chart-container {
    flex: 1 1 100%;
  }
}
</style>