<template>
  <NavBar />
      
  <div class="container mt-5">
    <div v-if="message" :class="{'alert-success': success, 'alert-danger': !success}" class="alert">
        {{ message }}
      </div><br><br><br>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">     
    
    <h1 class="mb-4">Library Dashboard</h1>
       
    <div class="mb-4">
      <div class="input-group">
        <input type="text" class="form-control" v-model="searchQuery" placeholder="Search...">
        <div class="input-group-append">
          <button class="btn btn-outline-secondary" type="button" @click="performSearch">Search</button>
        </div>
      </div>
      <div class="mt-2">
        <div class="form-check form-check-inline" v-for="option in searchOptions" :key="option">
          <input class="form-check-input" type="radio" :id="option" :value="option" v-model="searchType">
          <label class="form-check-label" :for="option">{{ option }}</label>
        </div>
      </div>
    </div>

    <div v-if="filteredSections.length === 0" class="alert alert-info">
      No sections available. Click 'Add Section' to create one.
    </div>

    <div v-else>
      <div v-for="section in filteredSections" :key="section.Section_id" class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0">
            <button class="btn btn-link" @click="toggleSection(section.Section_id)">
              {{ section.Section_Title }}
            </button>
          </h5>
          <div>
            <button class="btn btn-success btn-sm" @click="addBook(section.Section_id)">Add Book</button>
            <button class="btn btn-warning btn-sm" @click="editSection(section.Section_id)">Edit Section</button>
            <button class="btn btn-danger btn-sm" @click="deleteSection(section.Section_id)">Delete Section</button>
          </div>
        </div>
        <div v-if="section.show" class="card-body">
          <p><strong>Description:</strong> {{ section.Section_Descript }}</p>
          <div v-if="section.books.length === 0" class="alert alert-light">
            No books in this section.
          </div>
          <div v-else>
            <ol class="list-group">
              <li v-for="book in section.books" :key="book.Book_id" class="list-group-item d-flex justify-content-between align-items-center">
                <button class="btn btn" @click="editBook(book.Book_id)">
                  <b>{{ book.Book_Name }}</b> by <i>{{ book.Author }}</i>
                </button>
                <button class="btn btn-danger btn-sm" @click="deleteBook(book.Book_id)">Delete</button>
              </li>
            </ol>
          </div>
        </div>
      </div>
  </div>

    <router-link to="/addSection" class="floating-btn">
      <i class="fas fa-plus"></i>
    </router-link>
  </div>
</template>

<script>
import apiService from '@/services/apiService';
import NavBar from './Navbar.vue';

export default {
  name: 'HomePage',
  components: {
    NavBar
  },
  data() {
    return {
      sections: [],
      searchQuery: '',
      searchType: 'Section',
      searchOptions: ['Section', 'Author', 'Title'],
      message: '',
      success: false,
    };
  },
  computed: {
    filteredSections() {
      if (!this.searchQuery) return this.sections;

      return this.sections.map(section => {
        const matchesSection = section.Section_Title.toLowerCase().includes(this.searchQuery.toLowerCase());
        
        let filteredBooks = section.books;
        if (this.searchType === 'All' || this.searchType === 'Title') {
          filteredBooks = section.books.filter(book => 
            book.Book_Name.toLowerCase().includes(this.searchQuery.toLowerCase())
          );
        } else if (this.searchType === 'Author') {
          filteredBooks = section.books.filter(book => 
            book.Author.toLowerCase().includes(this.searchQuery.toLowerCase())
          );
        }

        const matchesBooks = filteredBooks.length > 0;

        if ((this.searchType === 'All' && (matchesSection || matchesBooks)) ||
            (this.searchType === 'Section' && matchesSection) ||
            ((this.searchType === 'Author' || this.searchType === 'Title') && matchesBooks)) {
          return { ...section, books: filteredBooks, show: true };
        }

        return null;
      }).filter(Boolean);
    }
  },
  methods: {
    showMessage(msg, isSuccess) {
      this.message = msg;
      this.success = isSuccess;
      setTimeout(() => {
        this.message = '';
      }, 3000);
    },
    toggleSection(id) {
      const section = this.sections.find(sec => sec.Section_id === id);
      section.show = !section.show;
    },
    async deleteBook(bookId) {
      try {
        await apiService.delete(`/library/deleteBook/${bookId}`);
        this.showMessage('Book deleted successfully', true);
        this.fetchSections();
      } catch (error) {
        this.showMessage('Book does not exist!', false);
      }
    },
    addBook(sectionId) {
      this.$router.push(`/addBook/${sectionId}`);
    },
    editBook(bookId) {
      this.$router.push(`/editBook/${bookId}`);
    },
    async deleteSection(sectionId) {
      try {
        await apiService.delete(`/library/deleteSection/${sectionId}`, {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.showMessage('Section deleted successfully', true);
        this.fetchSections();
      } catch (error) {
          if (error.response) {
            if (error.response.status === 401) {
              this.showMessage('Please delete the books in this section first!',false);
            } else {
              this.showMessage('Section does not exist!',false);
            }
          } else {
            this.showMessage('Network error',false);
          }
        }
    },
    editSection(sectionId) {
      this.$router.push(`/editSection/${sectionId}`);
    },
    async fetchSections() {
      try {
        const response = await apiService.get('/library/getSections');
        this.sections = response.data.map(section => ({ ...section, show: false }));
      } catch (error) {
        console.error('Error fetching sections:', error);
      }
    },
  },
  mounted() {
    if (sessionStorage.getItem('loggedIn')){
      if (sessionStorage.getItem('role') === 'admin') {
        this.$router.push('/home');
      } else {
        this.$router.push('/userHome');
      }
    } else {
      this.$router.push('/');
    }
    this.fetchSections();
  }
};
</script>

<style scoped>
.alert {
  position: fixed;
  top: 80px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1001;
  padding: 15px;
  border-radius: 4px;
  text-align: center;
  min-width: 300px;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.container {
  margin-top: 80px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  min-height: 100vh; 
  font-family: 'Times New Roman', serif; 
}
.btn {
  padding: 8px 16px;
  margin: 5px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.btn-link {
  background: none;
  border: none;
  color: #007bff;
  cursor: pointer;
  padding: 0;
}
.card {
  background-color: white;
  margin-top: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}
.card-header {
  padding: 15px;
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}
.card-body {
  padding: 15px;
}
.input-group {
  width: 100%;
  max-width: 500px;
  margin: 0 auto;
}
.form-check-inline {
  margin-right: 15px;
}
.floating-btn {
  position: relative;
  margin-top: auto; 
  width: 60px;
  height: 60px;
  background-color: #007bff;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  font-size: 24px;
  text-align: center;
  line-height: 60px;
  z-index: 1000;
  transition: background-color 0.3s, box-shadow 0.3s;
  text-decoration: none;
  position: fixed;
  left: 50%;
  bottom: 20px;
  transform: translateX(-50%);
}
.floating-btn:hover {
  background-color: #0056b3;
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
}
.floating-btn i {
  pointer-events: none;
}
</style>
