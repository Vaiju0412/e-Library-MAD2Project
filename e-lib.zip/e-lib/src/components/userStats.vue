<template>
  <div>
    <NavBar />
    <div class="stats-page">
      <h1>Statistics</h1>
      <div class="charts-container">
        <div class="chart-container">
          <canvas v-if="hasIssuedBooks" id="userIssuedBooksChart"></canvas>
          <div v-else class="no-data-message">
            <p>You have not issued any books.</p>
          </div>
        </div>
        <div class="chart-container">
          <canvas v-if="hasReturnedBooks" id="userReturnedBooksChart"></canvas>
          <div v-else class="no-data-message">
            <p>You have not returned any books.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);
import NavBar from "./Navbar.vue";
import apiService from "@/services/apiService";

export default {
  name: "UserStats",
  components: {
    NavBar,
  },
  data() {
    return {
      issuedBooksData: {},
      returnedBooksData: {},
    };
  },
  computed: {
    hasIssuedBooks() {
      return Object.keys(this.issuedBooksData).length > 0;
    },
    hasReturnedBooks() {
      return Object.keys(this.returnedBooksData).length > 0;
    },
  },
  mounted() {
    this.fetchIssuedBooksData();
    this.fetchReturnedBooksData();
  },
  methods: {
    async fetchIssuedBooksData() {
      try {
        const response = await apiService.get("/user/getIssuedBooks", {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.issuedBooksData = response.data;
        if (this.hasIssuedBooks) {
          this.$nextTick(() => {
            this.createIssuedBooksChart();
          });
        }
      } catch (error) {
        console.error("Error fetching issued books data:", error);
      }
    },
    async fetchReturnedBooksData() {
      try {
        const response = await apiService.get("/user/getReturnedBooks", {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.returnedBooksData = response.data;
        if (this.hasReturnedBooks) {
          this.$nextTick(() => {
            this.createReturnedBooksChart();
          });
        }
      } catch (error) {
        console.error("Error fetching returned books data:", error);
      }
    },
    createIssuedBooksChart() {
      const ctx = document.getElementById("userIssuedBooksChart");
      new Chart(ctx, {
        type: "bar",
        data: {
          labels: Object.keys(this.issuedBooksData),
          datasets: [
            {
              label: "Count",
              data: Object.values(this.issuedBooksData),
              backgroundColor: "rgba(75, 192, 192, 0.6)",
              borderColor: "rgba(75, 192, 192, 1)",
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Books Issued Distribution' }
          },
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    },
    createReturnedBooksChart() {
      const ctx = document.getElementById("userReturnedBooksChart");
      new Chart(ctx, {
        type: "pie",
        data: {
          labels: Object.keys(this.returnedBooksData),
          datasets: [{
            data: Object.values(this.returnedBooksData),
            backgroundColor: [
              'rgba(255, 99, 132, 0.6)',
              'rgba(54, 162, 235, 0.6)',
              'rgba(255, 206, 86, 0.6)',
              'rgba(75, 192, 192, 0.6)',
              'rgba(153, 102, 255, 0.6)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
            ],
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Books Returned Distribution' }
          }
        }
      });
    },
  },
};
</script>

<style scoped>
.stats-page {
  font-family: 'Times New Roman', Times, serif;
  padding: 40px;
  max-width: 1200px;
  margin: 0 auto;
  background-color: #f8f9fa;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

h1 {
  font-size: 2.5rem;
  color: #333;
  margin-bottom: 30px;
  text-align: center;
}

.charts-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 30px;
}

.chart-container {
  flex: 1 1 calc(50% - 15px);
  min-width: 300px;
  height: 400px;
  background-color: #ffffff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.chart-container:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

.chart-container canvas {
  width: 100% !important;
  height: 100% !important;
}

.no-data-message {
  text-align: center;
  font-size: 1.2rem;
  color: #666;
}

@media (max-width: 768px) {
  .stats-page {
    padding: 20px;
  }

  h1 {
    font-size: 2rem;
  }

  .chart-container {
    flex: 1 1 100%;
  }
}
</style>