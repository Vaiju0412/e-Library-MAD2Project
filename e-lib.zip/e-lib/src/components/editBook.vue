<template>
  <div class="page-wrapper">
    <NavBar />
    <div class="container">
      <div
        v-if="message"
        :class="{'alert-success': success, 'alert-danger': !success}"
        class="alert mt-3"
      >
        {{ message }}
      </div>
      <h2 class="page-title">Edit Book</h2>
      <form @submit.prevent="submitForm" class="form">
        <div class="form-group">
          <label for="book_name">Book Name</label>
          <input
            type="text"
            v-model="book_name"
            class="form-control"
            id="book_name"
            placeholder="book_name"
            required
          />
        </div>
        <div class="form-group">
          <label for="author">Author</label>
          <input
            type="text"
            v-model="author"
            class="form-control"
            id="author"
            placeholder="author"
            required
          />
        </div>
        <div class="form-group">
          <label for="content">Content</label>
          <textarea
            v-model="content"
            class="form-control"
            id="content"
            placeholder="content"
            required
          ></textarea>
        </div>
        <div class="form-group">
          <label for="synopsis">Synopsis</label>
          <textarea
            v-model="synopsis"
            class="form-control"
            id="synopsis"
            placeholder="synopsis"
            required
          ></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Edit Book</button>
      </form>
    </div>
  </div>
</template>

<script>
import apiService from '@/services/apiService';
import NavBar from '@/components/Navbar.vue';

export default {
  components: {
    NavBar
  },
  data() {
    return {
      book_name: '',
      author: '',
      content: '',
      synopsis: '',
      message: '',
      success: false,
    };
  },
  methods: {
    async fetchBookDetails() {
      const book_id = this.$route.params.book_id;
      try {
        const response = await apiService.get(`/library/getBooks/${book_id}`, {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        const book = response.data;
        this.book_name = book.Book_Name;
        this.author = book.Author;
        this.content = book.Content;
        this.synopsis = book.Synopsis;
      } catch (error) {
        this.message = 'Error fetching book details';
        this.success = false;
      }
    },
    async submitForm() {
      const book_id = this.$route.params.book_id;

      try {
        const response = await apiService.put(`/library/editBook/${book_id}`, {
          book_name: this.book_name,
          author: this.author,
          content: this.content,
          synopsis: this.synopsis,
        }, {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.message = response.data.message;
        this.success = true;
        
        setTimeout(() => {
          this.$router.push('/home');
        }, 2000);
        
      } catch (error) {
        if (error.response) {
          if (error.response.status === 401) {
            this.message = 'Book already exists';
          } else if (error.response.status === 404) {
            this.message = 'Book not found';
          } else {
            this.message = 'An error occurred';
          }
        } else {
          this.message = 'Network error';
        }
        this.success = false;
      }
    }
  },
  created() {
    this.fetchBookDetails();
  },
  mounted() {
    if (!sessionStorage.getItem('loggedIn')) {
      this.$router.push('/');
    }
  }
};
</script>

<style scoped>
.page-wrapper {
  font-family: 'Times New Roman', Times, serif;
  background-color: #f5f5f5;
  min-height: 100vh;
  padding-top: 80px;
}

.container {
  max-width: 600px;
  margin: 0 auto;
  background-color: #ffffff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.page-title {
  color: #333;
  font-size: 28px;
  margin-bottom: 30px;
  text-align: center;
  font-weight: bold;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 16px;
  color: #333;
}

.form-control {
  border-radius: 4px;
  border: 1px solid #ddd;
  padding: 10px;
  font-size: 16px;
}

.btn-primary {
  background-color: #007bff;
  border-color: #007bff;
  color: #fff;
}

.btn-primary:hover {
  background-color: #0056b3;
  border-color: #004085;
}

.alert {
  padding: 15px;
  border-radius: 4px;
  font-size: 16px;
  text-align: center;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
</style>
