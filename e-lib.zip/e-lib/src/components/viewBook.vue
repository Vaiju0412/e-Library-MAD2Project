<template>
  <div class="page-wrapper">
    <NavBar />    
    <div class="container">
      <div v-if="message" :class="{'alert-success': success, 'alert-danger': !success}" class="alert">
        {{ message }}
      </div><br><br>      
      <div class="card">
        <div class="card-header">
          <h2>{{ book.Book_Name }}</h2>
          <p class="text-muted">by {{ book.Author }}</p>
        </div>
        <div class="card-body">
          <h4>Synopsis</h4>
          <p>{{ book.Synopsis }}</p>
          <h4>Content</h4>
          <p>{{ book.Content }}</p>
          <form @submit.prevent="returnBook(book.Book_id)" class="form">
            <div class="form-group">
              <label for="feedback"><b>How did you find this book?</b></label>
              <input 
                type="text" 
                v-model="feedback" 
                id="feedback" 
                class="form-control"
                placeholder="Your feedback"
              />
            </div>
            <button type="submit" class="btn btn-warning mt-3">Return</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import apiService from '@/services/apiService';
import NavBar from './Navbar.vue';

export default {
  name: 'ViewBook',
  components: {
    NavBar
  },
  data() {
    return {
      book: {},
      feedback: '',
      message: '',
      success: false
    };
  },
  methods: {
    showMessage(msg, isSuccess) {
      this.message = msg;
      this.success = isSuccess;
      setTimeout(() => {
        this.message = '';
      }, 3000);
    },
    async fetchBook() {
      const bookId = this.$route.params.book_id;
      try {
        const response = await apiService.get(`/user/viewBook/${bookId}`, {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.book = response.data;
        this.success = true;
      } catch (error) {
        console.error('Error fetching book details:', error);
      }
    },
    async returnBook(book_id) {
      try {
        await apiService.put(`/user/returnBook/${book_id}`, { feedback: this.feedback }, {
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.showMessage("Book returned successfully!",true);
        this.$router.push('/userHome'); 
      } catch (error) {
        this.showMessage('Book is already reviewed!', false);
        this.$router.push('/userHome');      }
    }
  },
  mounted() {
    if(!sessionStorage.getItem('loggedIn')){
      this.$router.push('/')
    }
    this.fetchBook();
  }
};
</script>

<style scoped>
.page-wrapper {
  font-family: 'Times New Roman', Times, serif;
  background-color: #f5f5f5;
  min-height: 100vh;
  padding-top: 80px;
}

.container {
  max-width: 800px;
  margin: 0 auto;
  background-color: #ffffff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.card {
  border: none;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 20px;
}

.card-header {
  background-color: #3b5998; /* Facebook blue */
  color: #ffffff;
  padding: 20px;
  border-bottom: none;
  text-align: center;
}

.card-header h2 {
  margin: 0;
  font-size: 2rem;
}

.card-header p {
  margin: 0;
  font-size: 1.2rem;
}

.card-body {
  padding: 20px;
}

.card-body h4 {
  margin-top: 20px;
  font-size: 1.5rem;
  color: #333;
}

.card-body p {
  font-size: 1rem;
  line-height: 1.5;
  color: #555;
}

.form-group {
  margin-bottom: 20px;
}

.form-control {
  border-radius: 4px;
  border: 1px solid #ddd;
  padding: 10px;
  font-size: 16px;
}

.btn-warning {
  background-color: #ffc107;
  border-color: #ffc107;
  color: #212529;
}

.btn-warning:hover {
  background-color: #e0a800;
  border-color: #d39e00;
}
.alert {
  padding: 15px;
  border-radius: 4px;
  font-size: 16px;
  text-align: center;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
</style>
