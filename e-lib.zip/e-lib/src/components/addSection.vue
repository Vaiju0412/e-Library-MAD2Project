<template>
  <div class="page-wrapper">
    <NavBar />
    <div class="container">
      <div v-if="message" :class="{'alert-success': success, 'alert-danger': !success}" class="alert mt-3">
        {{ message }}
      </div>
      <h2 class="page-title">Add New Section</h2>
      <form @submit.prevent="submitForm" class="section-form">
        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" v-model="title" class="form-control" id="title" required />
        </div>
        <div class="form-group">
          <label for="descript">Description</label>
          <textarea v-model="descript" class="form-control" id="descript" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary submit-btn">Add Section</button>
      </form>
    </div>
  </div>
</template>

<script>
import apiService from '@/services/apiService';
import NavBar from '@/components/Navbar.vue';

export default {
  components: {
    NavBar
  },
  data() {
    return {
      title: '',
      descript: '',
      message: '',
      success: false,
    };
  },
  methods: {
    async submitForm() {
      try {
        const response = await apiService.post('/library/addSection', {
          title: this.title,
          descript: this.descript,
        });
        this.message = response.data.message;
        this.success = true;
        this.title = '';
        this.descript = '';
        setTimeout(() => {
          this.$router.push('/home');
        }, 2000);
      } catch (error) {
        if (error.response) {
          if (error.response.status === 401) {
            this.message = 'Section already exists';
          } else {
            this.message = 'An error occurred';
          }
        } else {
          this.message = 'Network error';
        }
        this.success = false;
      }
    },
  },
  mounted(){
    if(!sessionStorage.getItem('loggedIn')){
      this.$router.push('/')
    }
  }
};
</script>

<style scoped>
.page-wrapper {
  font-family: 'Times New Roman', Times, serif;
  background-color: #f5f5f5;
  min-height: 100vh;
  padding-top: 80px;
}

.container {
  max-width: 800px;
  margin: 0 auto;
  background-color: #ffffff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.page-title {
  color: #333;
  font-size: 28px;
  margin-bottom: 30px;
  text-align: center;
  font-weight: bold;
}

.section-form {
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 20px;
}

label {
  font-weight: bold;
  color: #555;
  display: block;
  margin-bottom: 5px;
}

.form-control {
  width: 100%;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
  transition: border-color 0.3s ease;
}

.form-control:focus {
  border-color: #007bff;
  outline: none;
}

.submit-btn {
  background-color: #007bff;
  color: white;
  font-size: 18px;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  width: 100%;
}

.submit-btn:hover {
  background-color: #0056b3;
}

.alert {
  padding: 15px;
  border-radius: 4px;
  font-size: 16px;
  text-align: center;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
</style>