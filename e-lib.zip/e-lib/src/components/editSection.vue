<template>
  <div class="page-wrapper">
    <NavBar />
    <div class="container">
      <div
        v-if="message"
        :class="{'alert-success': success, 'alert-danger': !success}"
        class="alert mt-3"
      >
        {{ message }}
      </div>
      <h2 class="page-title">Edit Section</h2>
      <form @submit.prevent="submitForm" class="form">
        <div class="form-group">
          <label for="title">Title</label>
          <input
            type="text"
            v-model="title"
            class="form-control"
            id="title"
            placeholder="Title"
            required
          />
        </div>
        <div class="form-group">
          <label for="descript">Description</label>
          <textarea
            v-model="descript"
            class="form-control"
            id="descript"
            placeholder="Description"
            required
          ></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Edit Section</button>
      </form>
    </div>
  </div>
</template>

<script>
import apiService from '@/services/apiService';
import NavBar from '@/components/Navbar.vue';

export default {
  components: {
    NavBar
  },
  data() {
    return {
      title: '',
      descript: '',
      message: '',
      success: false,
    };
  },
  methods: {
    async fetchSectionDetails() {
      const section_id = this.$route.params.section_id;
      try {
        const response = await apiService.get(`/library/getSection/${section_id}`,{
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        const section = response.data;
        this.title = section.Section_Title;
        this.descript = section.Section_Descript;
      } catch (error) {
        this.message = 'Error fetching section details';
        this.success = false;
      }
    },
    async submitForm() {
      const section_id = this.$route.params.section_id;

      try {
        const response = await apiService.put(`/library/editSection/${section_id}`, {
          title: this.title,
          descript: this.descript,
        },{
          headers: { Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}` }
        });
        this.message = response.data.message;
        this.success = true;
        setTimeout(() => {
          this.$router.push('/home');
        }, 2000);
      } catch (error) {
        if (error.response) {
          if (error.response.status === 401) {
            this.message = 'Section already exists';
          } else if (error.response.status === 404) {
            this.message = 'Section not found';
          } else {
            this.message = 'An error occurred';
          }
        } else {
          this.message = 'Network error';
        }
        this.success = false;
      }
    }
  },
  created() {
    this.fetchSectionDetails();
  },
  mounted() {
    if (!sessionStorage.getItem('loggedIn')) {
      this.$router.push('/');
    }
  }
};
</script>

<style scoped>
.page-wrapper {
  font-family: 'Times New Roman', Times, serif;
  background-color: #f5f5f5;
  min-height: 100vh;
  padding-top: 80px;
}

.container {
  max-width: 600px;
  margin: 0 auto;
  background-color: #ffffff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.page-title {
  color: #333;
  font-size: 28px;
  margin-bottom: 30px;
  text-align: center;
  font-weight: bold;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 16px;
  color: #333;
}

.form-control {
  border-radius: 4px;
  border: 1px solid #ddd;
  padding: 10px;
  font-size: 16px;
}

.btn-primary {
  background-color: #007bff;
  border-color: #007bff;
  color: #fff;
}

.btn-primary:hover {
  background-color: #0056b3;
  border-color: #004085;
}

.alert {
  padding: 15px;
  border-radius: 4px;
  font-size: 16px;
  text-align: center;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
</style>
