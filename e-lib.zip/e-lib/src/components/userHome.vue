<template>
  <div class="page-wrapper">
    <NavBar />
    <div class="container">
      <div v-if="message" :class="{'alert-success': success, 'alert-danger': !success}" class="alert">
        {{ message }}
      </div><br><br>
      <h1 class="page-title">Welcome to e-library</h1>

      <div class="search-section">
        <div class="input-group">
          <input
            type="text"
            class="form-control"
            v-model="searchQuery"
            placeholder="Search..."
          />
          <div class="input-group-append">
            <button
              class="btn btn-outline-secondary"
              type="button"
              @click="performSearch"
            >
              Search
            </button>
          </div>
        </div>
        <div class="mt-2">
          <div
            class="form-check form-check-inline"
            v-for="option in searchOptions"
            :key="option"
          >
            <input
              class="form-check-input"
              type="radio"
              :id="option"
              :value="option"
              v-model="searchType"
            />
            <label class="form-check-label" :for="option">{{ option }}</label>
          </div>
        </div>
      </div>

      <div v-for="(books, section) in groupedBooks" :key="section">
        <h2>{{ section }}</h2>
        <div class="row book-cards">
          <div
            class="col-md-4 mb-4"
            v-for="book in books"
            :key="book.Book_id"
          >
            <div v-if="!book.Returned" class="card book-card">
              <div class="card-body">
                <h5 class="card-title">{{ book.Book_Name }}</h5>
                <p class="card-text"><strong>Author:</strong> {{ book.Author }}</p>
                <div v-if="!book.Requested && !book.Issued">
                  <button
                    class="btn btn-primary"
                    @click="openRequestModal(book.Book_id)"
                  >
                    Request Access
                  </button>
                  <button
                    class="btn btn-secondary"
                    @click="openDetailsModal(book.Book_id)"
                  >
                    Details
                  </button>
                </div>
                <div v-else-if="book.Issued">
                  <button
                    class="btn btn-primary"
                    @click="viewBook(book.Book_id)"
                  >
                    View Book
                  </button>
                </div>
                <div v-else-if="book.Requested && !book.Issued">
                  <button
                    class="btn btn-danger"
                    @click="revokeRequest(book.Book_id)"
                  >
                    Revoke
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div ref="requestModal" class="modal" :class="{ show: showModal }">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Request Access</h5>
              <button type="button" class="close" @click="closeRequestModal">
                &times;
              </button>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <div class="row">
                  <div class="col-md-6">
                    <label for="duration">Duration</label>
                    <select
                      id="duration"
                      class="form-control"
                      v-model="selectedDuration"
                    >
                      <option value="Hours">Hours</option>
                      <option value="Days">Days</option>
                      <option value="Weeks">Weeks</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <label for="value">Value</label>
                    <input
                      id="value"
                      type="number"
                      class="form-control"
                      v-model="requestDuration"
                      min="1"
                    />
                  </div>
                </div>
              </div>
              <button
                class="btn btn-primary mt-3"
                @click="submitRequest"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>

      <div
        ref="detailsModal"
        class="modal"
        :class="{ show: showDetailsModal }"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Book Details</h5>
              <button type="button" class="close" @click="closeDetailsModal">
                &times;
              </button>
            </div>
            <div class="modal-body">
              <p><strong>Title:</strong> {{ selectedBook.Book_Name }}</p>
              <p><strong>Author:</strong> {{ selectedBook.Author }}</p>
              <p><strong>Description:</strong> {{ selectedBook.Synopsis }}</p>
              <p><strong>Feedbacks</strong></p>
              <div
                v-if="selectedBook.Feedbacks && selectedBook.Feedbacks.length > 0"
              >
                <ul>
                  <li
                    v-for="feedback in selectedBook.Feedbacks"
                    :key="feedback.user_id"
                  >
                    <strong>{{ feedback.user_id }}: </strong>
                    {{ feedback.feedback }}
                  </li>
                </ul>
              </div>
              <p v-else>No feedback available for this book.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import apiService from "@/services/apiService";
import NavBar from "./Navbar.vue";

export default {
  name: "UserHome",
  components: {
    NavBar,
  },
  data() {
    return {
      books: [],
      requestDuration: 1,
      selectedDuration: "Hours",
      selectedBookId: null,
      selectedBook: {},
      searchQuery: "",
      searchType: "All",
      searchOptions: ["All", "Title", "Author","Section"],
      showModal: false,
      showDetailsModal: false,
      message: '',
      success: false,
    };
  },
  computed: {
    groupedBooks() {
      const filteredBooks = this.books.filter((book) => {
        const matchesTitle = book.Book_Name.toLowerCase().includes(
          this.searchQuery.toLowerCase()
        );
        const matchesAuthor = book.Author.toLowerCase().includes(
          this.searchQuery.toLowerCase()
        );
        const matchesSection = book.Section_name.toLowerCase().includes(
          this.searchQuery.toLowerCase()
        );

        switch (this.searchType) {
          case "All":
            return matchesTitle || matchesAuthor;
          case "Title":
            return matchesTitle;
          case "Author":
            return matchesAuthor;
            case "Section":
            return matchesSection;
          default:
            return false;
        }
      });

      return filteredBooks.reduce((sections, book) => {
        const section = book.Section_name;
        if (!sections[section]) {
          sections[section] = [];
        }
        sections[section].push(book);
        return sections;
      }, {});
    },
  },
  methods: {
    showMessage(msg, isSuccess) {
      this.message = msg;
      this.success = isSuccess;
      setTimeout(() => {
        this.message = '';
      }, 3000);
    },
    async fetchBooks() {
      try {
        const response = await apiService.get("/user/getBooks", {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("accesstoken")}`,
          },
        });
        this.books = response.data;
      } catch (error) {
        console.error("Error fetching books:", error);
      }
    },
    openRequestModal(bookId) {
      this.selectedBookId = bookId;
      this.showModal = true;
    },
    closeRequestModal() {
      this.showModal = false;
    },
    async submitRequest() {
      try {
        await apiService.post(
          "/user/requestAccess",
          {
            bookId: this.selectedBookId,
            duration: this.selectedDuration,
            value: this.requestDuration,
          },
          {
            headers: {
              Authorization: `Bearer ${sessionStorage.getItem("accesstoken")}`,
            },
          }
        );
        this.closeRequestModal();
        this.showMessage('Request submitted successfully', true);
        this.fetchBooks();
      } catch (error) {
        console.error("Error requesting access:", error);
      }
    },
    async openDetailsModal(bookId) {
      await this.fetchBookDetails(bookId);
      this.showDetailsModal = true;
    },
    async fetchBookDetails(bookId) {
      try {
        const response = await apiService.get(`/user/details/${bookId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("accesstoken")}`,
          },
        });
        this.selectedBook = response.data;
      } catch (error) {
        console.error("Error fetching book details:", error);
      }
    },
    closeDetailsModal() {
      this.showDetailsModal = false;
    },
    viewBook(bookId) {
      this.$router.push(`/viewBook/${bookId}`);
    },
    async revokeRequest(bookId) {
      try {
        await apiService.delete(`user/revoke/${bookId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("accesstoken")}`,
          },
        });
        this.showMessage('Book revoked successfully', true);
        this.fetchBooks();
      } catch (error) {
        console.error("Error revoking request:", error);
      }
    },
  },
  mounted() {
    if (!sessionStorage.getItem("loggedIn")) {
      this.$router.push("/");
    }
    this.fetchBooks();
  },
};
</script>

<style scoped>
.page-wrapper {
  font-family: "Times New Roman", Times, serif;
  background-color: #f5f5f5;
  min-height: 100vh;
  padding-top: 80px;
}

.container {
  max-width: 1000px;
  margin: 0 auto;
  background-color: #ffffff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.page-title {
  color: #333333;
  font-weight: bold;
  text-align: center;
  margin-bottom: 30px;
}

.search-section {
  margin-bottom: 30px;
}

.input-group {
  max-width: 500px;
  margin: 0 auto;
}

.book-cards {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}

.book-card {
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  transition: transform 0.3s ease;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.book-card:hover {
  transform: translateY(-5px);
}

.card-body {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.card-title {
  font-size: 1.25rem;
  margin-bottom: 10px;
}

.card-text {
  margin-bottom: 20px;
}

.btn {
  margin-bottom: 10px;
}

.modal.show {
  display: block;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-dialog {
  margin-top: 100px;
}

.modal-body p,
.modal-body h5 {
  margin-bottom: 10px;
}

.modal-body ul {
  padding-left: 20px;
}

.modal-body li {
  margin-bottom: 5px;
}

.form-check-label {
  color: #333;
}

.form-check-input:checked ~ .form-check-label {
  color: #007bff;
}

.row {
  display: flex;
  flex-wrap: wrap;
}

.col-md-4 {
  flex: 1 1 calc(33.333% - 20px);
  box-sizing: border-box;
}

@media (max-width: 768px) {
  .col-md-4 {
    flex: 1 1 100%;
  }
}
</style>
