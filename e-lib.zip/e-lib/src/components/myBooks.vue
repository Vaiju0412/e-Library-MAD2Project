<template>
  <div class="page-wrapper">
    <NavBar />
    <div class="container">
      <div v-if="message" :class="{'alert-success': success, 'alert-danger': !success}" class="alert mt-3">
        {{ message }}
      </div>
      <h1 class="page-title">User Book Requests</h1>

      <div v-if="userBooks.length === 0" class="alert alert-info">
        No book requests available.
      </div>

      <div v-else>
        <div class="section">
          <h2 class="section-title">Pending Requests</h2>
          <div v-if="pendingRequests.length === 0" class="alert alert-light">
            No pending requests.
          </div>
          <div v-else>
            <ul class="list-group mb-4">
              <li
                v-for="request in pendingRequests"
                :key="request.Book_id"
                class="list-group-item d-flex justify-content-between align-items-center"
              >
                <div class="text-left">
                  <p>
                    <strong>{{ request.Book_Name }}</strong> by
                    <i>{{ request.Author }}</i>
                  </p>
                  <p>
                    <strong>Date of return:</strong>
                    <i>{{ request.expiration_period }}</i>
                  </p>
                </div>
                <div>
                  <button
                    class="btn btn-danger mr-2"
                    @click="revoke(request.Book_id)"
                  >
                    Revoke
                  </button>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div class="section">
          <h2 class="section-title">Issued Books</h2>
          <div v-if="issuedRequests.length === 0" class="alert alert-light">
            No issued books.
          </div>
          <div v-else>
            <ul class="list-group mb-4">
              <li
                v-for="request in issuedRequests"
                :key="request.user_book_id"
                class="list-group-item d-flex justify-content-between align-items-center"
              >
                <div class="text-left">
                  <p>
                    <strong>{{ request.Book_Name }}</strong> by
                    <i>{{ request.Author }}</i>
                  </p>
                  <i>Date of return: {{ request.expiration_period }}</i>
                </div>
                <div>
                  <button
                    class="btn btn-warning"
                    @click="viewBook(request.Book_id)"
                  >
                    View Book
                  </button>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div class="section">
          <h2 class="section-title">Rejected Requests</h2>
          <div v-if="rejectedRequests.length === 0" class="alert alert-light">
            No rejected requests.
          </div>
          <div v-else>
            <ul class="list-group mb-4">
              <li
                v-for="request in rejectedRequests"
                :key="request.user_book_id"
                class="list-group-item"
              >
                <div class="text-left">
                  <p>
                    <strong>{{ request.Book_Name }}</strong> by
                    <i>{{ request.Author }}</i>
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import apiService from '@/services/apiService';
import NavBar from './Navbar.vue';

export default {
  name: 'myBooks',
  components: {
    NavBar,
  },
  data() {
    return {
      userBooks: [],
      message: '',
      success: false,
    };
  },
  computed: {
    pendingRequests() {
      return this.userBooks.filter((book) => book.Requested === true);
    },
    issuedRequests() {
      return this.userBooks.filter((book) => book.Issued === true);
    },
    rejectedRequests() {
      return this.userBooks.filter((book) => book.Rejected === true);
    },
  },
  methods: {
    showMessage(msg, isSuccess) {
      this.message = msg;
      this.success = isSuccess;
      setTimeout(() => {
        this.message = '';
      }, 3000);
    },
    async fetchUserBooks() {
      try {
        const response = await apiService.get('user/getBooks', {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}`,
          },
        });
        this.userBooks = response.data;
      } catch (error) {
        console.error('Error fetching user books:', error);
        this.success = false;
      }
    },
    async revoke(bookId) {
      try {
        await apiService.delete(`/user/revoke/${bookId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('accesstoken')}`,
          },
        });
        this.showMessage('Book revoked successfully', true);
        this.fetchUserBooks();
      } catch (error) {
        if (error.response) {
            if (error.response.status === 404) {
              this.showMessage('Book not Found!',false);
            } else {
              this.showMessage('Book not requested by user!',false);
            }
          } else {
            this.showMessage('Network error',false);
          }
      }
    },
    viewBook(bookId) {
      this.$router.push(`/viewBook/${bookId}`);
    },
  },
  mounted() {
    if (!sessionStorage.getItem('loggedIn')) {
      this.$router.push('/');
    }
    this.fetchUserBooks();
  },
};
</script>

<style scoped>
.page-wrapper {
  font-family: 'Times New Roman', Times, serif;
  background-color: #f5f5f5;
  min-height: 100vh;
  padding-top: 80px;
}

.container {
  max-width: 800px;
  margin: 0 auto;
  background-color: #ffffff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.page-title {
  color: #333;
  font-size: 28px;
  margin-bottom: 30px;
  text-align: center;
  font-weight: bold;
}

.section {
  margin-bottom: 20px;
}

.section-title {
  font-size: 24px;
  color: #333;
  margin-bottom: 20px;
}

.text-left {
  text-align: left;
}
.alert {
  padding: 15px;
  border-radius: 4px;
  font-size: 16px;
  text-align: center;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.alert-danger {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
</style>
