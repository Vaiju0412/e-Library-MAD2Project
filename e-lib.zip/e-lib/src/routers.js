import HomePage from './components/HomePage.vue';
import Login from './components/Login.vue';
import adminLogin from './components/adminLogin.vue';
import SignUp from './components/SignUp.vue';
import addSection from './components/addSection.vue';
import addBook from './components/addBook.vue';
import editBook from './components/editBook.vue';
import editSection from './components/editSection.vue';
import viewRequest from './components/viewRequest.vue';
import userHome from './components/userHome.vue';
import viewBook from './components/viewBook.vue'
import libStats from './components/libStats.vue';
import userStats from './components/userStats.vue';
import myBooks from './components/myBooks.vue';
import {createRouter, createWebHistory} from 'vue-router';

const routes =[
    {
        name: 'HomePage',
        component: HomePage,
        path: '/home',
    },
    {
        name: 'SignUp',
        component: SignUp,
        path:'/sign-up',
    },
    {
        name: 'LibLogin',
        component: Login,
        path:'/',
    },
    {
        name: 'adminLogin',
        component: adminLogin,
        path:'/admin',
    },
    {
        name: 'addSection',
        component: addSection,
        path:'/addSection',
    },
    {
        name: 'addBook',
        component: addBook,
        path:'/addBook/:section_id',
    },
    {
        name: 'editBook',
        component: editBook,
        path:'/editBook/:book_id',
    },
    {
        name: 'editSection',
        component: editSection,
        path:'/editSection/:section_id',
    },
    {
        name: 'viewRequest',
        component: viewRequest,
        path:'/viewRequest',
    },
    {
        name: 'myBooks',
        component: myBooks,
        path:'/myBooks',
    },
    {
        name: 'userHome',
        component: userHome,
        path:'/userHome',
    },
    {
        name: 'viewBook',
        component: viewBook,
        path:'/viewBook/:book_id',
    },
    {
        name: 'libStats',
        component: libStats,
        path:'/libStats',
    },
    {
        name: 'userStats',
        component: userStats,
        path:'/userStats',
    },


];

const router = createRouter({
    history:createWebHistory(),
    routes,
});

export default router;