from flask_restx import Resource, Namespace, marshal
from datetime import datetime, timedelta
from .models import *
from .imports import * 
from .api_models import *
from sqlalchemy import func, and_
from flask_jwt_extended import jwt_required, get_jwt_identity, create_access_token, current_user


authorizations = {
    "jsonwebtoken": {
        "type": "apiKey",
        "in": "header",
        "name": "Authorization"
    }
}


blocklist = set()

lib = Namespace("library", authorizations = authorizations )
usr = Namespace("user", authorizations = authorizations)

@usr.route('/signup')
class Signup(Resource):
    @lib.expect(signup_input)
    def post(self):

        data = lib.payload

        user_id = data.get('user_id')
        firstName = data.get('firstName')
        password1 = data.get('password1')
        password2 = data.get('password2')

        user = User.query.filter_by(user_id = user_id).first()

        if user:
            return {'message': 'User already exists.'}, 400
        elif password1 != password2:
            return {'message': 'Passwords don\'t match. Please try again.'}, 406
        else:
            new_user = User(user_id = user_id, firstName = firstName, password = password1)

        db.session.add(new_user)
        db.session.commit()        
        return {'message': 'Account created successfully!'}, 200
    

@usr.route('/login')
class Login(Resource):
    @lib.expect(login_input)
    def post(self):
        data = lib.payload
        user_id = data.get('user_id')
        password = data.get('password')

        user = User.query.filter_by(user_id=user_id).first()

        if user and user.password == password:
            return {'accesstoken': create_access_token(identity = user)}, 200
        else:
            return {'message': 'Invalid Username or Password, please try again.'}, 401

@lib.route('/addSection')
class addSection(Resource): 
    @lib.expect(section)
    def post(self):
        data = lib.payload
        title = data.get('title')
        descript = data.get('descript')

        section = Section.query.filter_by(Section_Title = title).first()

        if section:
            return {'message': 'Section already exists'},401
        else:
            new_section = Section(Section_Title = title, Section_Descript = descript)

        db.session.add(new_section)
        db.session.commit()         
        return {'message':'Section created successfully!'},200


@lib.route('/getSections')
class getSections(Resource):
    @lib.marshal_list_with(getSections)
    def get(self):
        sections = Section.query.all()
        return sections,200
    
@lib.route('/getSection/<int:section_id>')
class getSect(Resource):
    @lib.marshal_list_with(getSection)
    def get(self,section_id):
        sections = Section.query.filter_by(Section_id = section_id).first()
        if not sections:
            return {'message':'Section not found'},404
        return sections,200

@lib.route('/deleteSection/<int:section_id>')
class deleteSection(Resource):
    def delete(self,section_id):
        section = Section.query.filter_by(Section_id = section_id).first()

        if not section:
            return {'message': 'Section does not exist!'}, 404
        
        if section.books:
            return {'message': 'Please delete the books in this section first!'}, 401
        
        db.session.delete(section)
        db.session.commit()
        return {'message': 'Section deleted successfully!'}, 200



@lib.route('/editSection/<int:section_id>')
class editSection(Resource): 
    @lib.expect(section)
    def put(self,section_id):
        data = lib.payload
        title = data.get('title')
        descript = data.get('descript')

        section = Section.query.filter_by(Section_Title = title).first()

        if section and section.Section_id != section_id:
            return {'message':'Section already exists!'},401
        
        section = Section.query.filter_by(Section_id = section_id).first()

        section.Section_Title = title
        section.Section_Descript = descript

        db.session.commit()
        return{'message':'Section edited successfully!'},200



@lib.route('/addBook/<int:section_id>')
class addBook(Resource): 
    @lib.expect(addBook)
    def post(self,section_id):
        data = lib.payload
        book_name = data.get('book_name')
        author = data.get('author')
        content = data.get("content")
        synopsis = data.get("synopsis")

        book = Book.query.filter_by(Book_Name = book_name).first()
        section = Section.query.filter_by(Section_id = section_id).first()

        if not section:
            return{'message': 'Section does not exists!'}, 404
        if book:
            return {'message': 'Book already exists'},401
        else:
            new_book = Book(Book_Name = book_name, Author = author, Content = content, Synopsis = synopsis,section_id = section_id)

        db.session.add(new_book)
        db.session.commit()         
        return {'message':'Book created successfully!'},200


@lib.route('/editBook/<int:book_id>')
class editBook(Resource): 
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    @lib.expect(editBook)
    def put(self,book_id):

        data = lib.payload
        book_name = data.get('book_name')
        author = data.get('author')
        content = data.get("content")
        synopsis = data.get("synopsis")

        book = Book.query.filter_by(Book_id = book_id).first()
        existing_book = Book.query.filter_by(Book_Name = book_name).first()

        if book:
            if existing_book and existing_book.Book_id != book.Book_id:
                return {'message': 'Book already exists'},401
        
            book.Book_Name = book_name
            book.Author = author
            book.Synopsis = synopsis
            book.Content = content
            db.session.commit()        

            return {'message':'Book edited successfully!'},200
        else:
            {'message': 'Book Not Found!'},404


@lib.route('/deleteBook/<int:book_id>')
class deleteBook(Resource):
    def delete(self,book_id):

        book = Book.query.filter_by(Book_id = book_id).first()
        if not book:
            return {'message': 'Book does not exist!'},404

        db.session.delete(book)
        db.session.commit()
        return {'message': 'Book deleted successfully!'}, 200
    
        
@lib.route('/request/<int:book_id>/<int:user_id>/<string:status>')
class grantReject(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def put(self,user_id,book_id,status):
        user = User.query.filter_by(id = user_id).first()
        if not user:
            return{'message':'User not found'},404
        
        book = Book.query.filter_by(Book_id = book_id)
        if not book:
            return{'message':'Book not found'},404
        
        user_book = User_Book.query.filter_by(User_id=user_id, Book_id=book_id).order_by(User_Book.user_book_id.desc()).first()
        if not user_book:
            return {'message':'No request was found!'}, 404
        
        if status == "Accept":
            if user.count_access < 5:
                user.count_access = user.count_access + 1          
                user_book.Status = "Issued"
                db.session.commit()
                return{'message':'Book issued successfully!'},200
            else:
                return{'message':'User has reached maximum limit'},403
        elif status == "Reject":
            user_book.Status = "Rejected"
            db.session.commit()
            return{'message':'Book rejected successfully'},200
        elif status == "Revoke":
            user.count_access = user.count_access - 1
            db.session.delete(user_book)
            db.session.commit()
            return{'message':'Book revoked successfully'},200
        else:
            return{'message':'Request not found'},406        
            
            
        
@usr.route('/requestAccess')
class makeRequest(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    @lib.expect(requestAccess)
    def post(self):
        data = lib.payload
        duration = data.get('duration')
        value = data.get('value')
        bookId = data.get('bookId')
        user_id = current_user.id
        user = User.query.filter_by(id = user_id).first()
        current_date = datetime.now()   

        if duration == 'Hours':
            expiration_time = current_date + timedelta(hours=int(value))
        
        if duration == 'Days':
            expiration_time = current_date + timedelta(days=int(value))
        
        if duration == 'Weeks':
            expiration_time = current_date + timedelta(weeks=int(value))
        

        if user.count_access < 5:
            book = Book.query.filter_by(Book_id = bookId).first()
            section = book.section
            new_user_book = User_Book(User_id = user_id, Book_id = bookId, Section_id = section.Section_id, expiration_period = expiration_time.strftime("%H:%M %dth %b, %Y "))
            db.session.add(new_user_book)     
            db.session.commit()
            return {'message': 'Request made successfully!'},200
        else:
            return {'message': 'Request error'},400


@usr.route('/details/<int:book_id>')
class viewDetails(Resource):
    @lib.marshal_list_with(viewDetails)
    def get(self, book_id):
        book = Book.query.filter_by(Book_id=book_id).first()
        if book:
            feedbacks = User_Book.query.filter_by(Book_id=book_id,Status="Returned").all()
            feedback_list = []
            for feedback in feedbacks:
                user = User.query.filter_by(id = feedback.User_id).first()
                feedback_list.append({"user_id": user.user_id, "feedback": feedback.feedback})

            book_details = {
                "Book_Name": book.Book_Name,
                "Author": book.Author,
                "Synopsis": book.Synopsis,
                "Feedbacks": feedback_list
            }
            return book_details, 200
        else:
            return {'message': 'Book not found!'}, 404
        

@usr.route('/viewBook/<int:book_id>')
class viewBook(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    @lib.marshal_list_with(viewBook)
    def get(self,book_id):
        user_id = current_user.id
        role = current_user.role
        
        user_book = User_Book.query.filter_by(User_id=user_id, Book_id=book_id).order_by(User_Book.user_book_id.desc()).first()
        if user_book.Status == "Issued" or role == "admin":
            book = Book.query.filter_by(Book_id = book_id).first()
            if book:
                return book,200
            else:
                return {'message':'Book not found!'},404
        else:
            return {'message':'Book Not Issued'}, 403
        
@usr.route('/returnBook/<int:book_id>')
class returnBook(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    @lib.expect(returnBook)
    def put(self,book_id):
        user_id = current_user.id
        user_book = User_Book.query.filter_by(User_id = user_id, Book_id = book_id,Status = "Issued").first()

        data = lib.payload
        feedback = data.get('feedback')
        user_book_returned = User_Book.query.filter_by(User_id = user_id,Book_id = book_id,Status = "Returned").first()

        
        if user_book:
            user_book.feedback = feedback
            user_book.Status = "Returned"
            user_book.expiration_period = ""

            user = User.query.filter_by(id = user_id).first()
            user.count_access = user.count_access - 1
            db.session.commit()   
            return{'message':'Book returned successfully!'},200
        if user_book_returned:
            return {'message': 'You have already reviewed this book once'},403
        
@usr.route('/revoke/<int:book_id>')
class revokeBook(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def delete(self,book_id):
        user_id = current_user.id
        book = Book.query.filter_by(Book_id = book_id).first()
        if book is None:
            return{'message':'Book not Found'},404
        user_book = User_Book.query.filter_by(User_id = user_id, Book_id = book_id).first()
        if user_book is None:
            return{'message':'Book not requested by user'},403
        else:
            db.session.delete(user_book)
            db.session.commit()
            return {'message':'Book revoked successfully'},200
        
# @lib.route('/revoke/admin/<int:book_id>/<int:user_id>')
# class revoke(Resource):
#     method_decorators = [jwt_required()]
#     @lib.doc(security="jsonwebtoken")
#     def delete(self,book_id,user_id):
#         role = current_user.role
#         if role != "admin":
#             return {'message':'Anauthorized access'},401
#         book = Book.query.filter_by(Book_id = book_id).first()
#         if book is None:
#             return{'message':'Book not Found'},404
#         user_book = User_Book.query.filter_by(User_id = user_id, Book_id = book_id, Status = "Issued").first()
        
#         if user_book is None:
#             return{'message':'Book not requested by user'},403
#         else:
#             user = User.query.filter_by(id = user_id).first()
#             if user is None:
#                 return {'message':'Invalid User'},404
#             db.session.delete(user_book)
#             user.count_access = user.count_access-1 
#             db.session.commit()
#             return {'message':'Book revoked successfully'},200

@lib.route('/getBooks/<int:book_id>')
class fetchBook(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    @lib.marshal_list_with(fetchBook)
    def get(self,book_id):
        role = current_user.role
        if role != 'admin':
            return {'message': 'Unauthorized access'}, 401
        book = Book.query.filter_by(Book_id = book_id).first()
        if not book:
            return {'message':'Book not found'},404
        return book, 200

@lib.route('/getBooks')
class getBooks(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def get(self):
        books_with_status = db.session.query(
            Book.Book_id,
            Book.Book_Name,
            Book.Author,
            User.id.label('id'),
            User.user_id.label('user_name'),
            db.case(
                (User_Book.Status == 'Pending', True),  
                else_=False
            ).label('Requested'),
            db.case(
                (User_Book.Status == 'Issued', True),  
                else_=False
            ).label('Issued'),
            db.case(
                (User_Book.Status == 'Rejected', True),  
                else_=False
            ).label('Rejected'),
            User_Book.expiration_period
        ).outerjoin(User_Book, Book.Book_id == User_Book.Book_id) \
         .outerjoin(User, User_Book.User_id == User.id) \
         .filter(User_Book.Status.in_(['Pending', 'Issued', 'Rejected'])) \
         .all()
        
        books = []
        for book in books_with_status:
            books.append({
                'Book_id': book.Book_id,
                'Book_Name': book.Book_Name,
                'id': book.id,
                'Author': book.Author,
                'user_name': book.user_name,
                'Requested': book.Requested,
                'Issued': book.Issued,
                'Rejected': book.Rejected,
                'expiration_period': book.expiration_period
            })
        return books, 200



@usr.route('/getBooks')
class getBooks(Resource):
    method_decorators = [jwt_required()]    
    @lib.doc(security="jsonwebtoken")
    def get(self):
        
        user_id = current_user.id

        user_books = db.session.query(User_Book).filter_by(User_id=user_id).all()

        user_book_status = {}
        for ub in user_books:
            if ub.Status == 'Pending':
                user_book_status[ub.Book_id] = {'Requested': True, 'Issued': False, 'Rejected': False, 'expiration_period': ub.expiration_period}
            elif ub.Status == 'Issued':
                user_book_status[ub.Book_id] = {'Requested': False, 'Issued': True, 'Rejected': False, 'expiration_period': ub.expiration_period}
            elif ub.Status == 'Rejected':
                user_book_status[ub.Book_id] = {'Requested': False, 'Issued': False, 'Rejected': True, 'expiration_period': ub.expiration_period}
        
        all_books = db.session.query(
            Book.Book_id,
            Book.Book_Name,
            Section.Section_Title,
            Book.Author
        ).join(Section, Book.section_id == Section.Section_id).all()

        books = []
        for book in all_books:
            status = user_book_status.get(book.Book_id, {'Requested': False, 'Issued': False, 'Rejected': False, 'expiration_period': None})
            
            books.append({
                'Book_id': book.Book_id,
                'Book_Name': book.Book_Name,
                'Section_name': book.Section_Title,
                'Author': book.Author,
                'Requested': status['Requested'],
                'Issued': status['Issued'],
                'Rejected': status['Rejected'],
                'expiration_period': status['expiration_period']  
            })
        print(books)
        return books, 200

       

@lib.route('/getIssuedBooks/admin')
class getIssuedBooks(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def get(self):
        stats = db.session.query(
            Section.Section_Title,
            func.count(User_Book.Status).label('issued_count')
        ).join(
            Book, Book.section_id == Section.Section_id
        ).join(
            User_Book, User_Book.Book_id == Book.Book_id
        ).filter(
            User_Book.Status == 'Issued'
        ).group_by(
            Section.Section_id
        ).all()

        
        result = {
            stat.Section_Title: int(stat.issued_count)
            for stat in stats
        }

        if result == {}:
            return {'message': 'No books issued!'}, 404  


        return result, 200
    
    
@lib.route('/getSectionBooks/admin')
class getSectionBooks(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def get(self):
        distribution = db.session.query(
                Section.Section_Title,
                func.count(Book.Book_id).label('book_count')
            ).join(
                Book, Book.section_id == Section.Section_id
            ).group_by(
                Section.Section_id
            ).all()
        
        result = {
                section.Section_Title: int(section.book_count)
                for section in distribution
            }
        
        if result == {}:
            return {'message': 'No books found!'}, 404  


        return result, 200

@usr.route('/getReturnedBooks')
class getReturnedBooks(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def get(self):
        id = current_user.id
        query = db.session.query(
        Section.Section_Title,
        func.count(User_Book.user_book_id).label('count')
    ).join(
        User_Book,
        User_Book.Section_id == Section.Section_id
    ).filter(
        User_Book.User_id == id,
        User_Book.Status == 'Returned'
    ).group_by(
        Section.Section_Title
    )

        result = query.all()

        section_counts = {section.Section_Title: section.count for section in result}
        if section_counts == {}:
            return {'message':'No books returned yet!'}, 404
        
        return section_counts, 200

@usr.route('/getIssuedBooks')
class getIssuedBooks(Resource):
    method_decorators = [jwt_required()]
    @lib.doc(security="jsonwebtoken")
    def get(self):
        id = current_user.id
        query = db.session.query(
        Section.Section_Title,
        func.count(User_Book.user_book_id).label('count')
    ).join(
        User_Book,
        User_Book.Section_id == Section.Section_id
    ).filter(
        User_Book.User_id == id,
        User_Book.Status == 'Issued'
    ).group_by(
        Section.Section_Title
    )

        result = query.all()

        section_counts = {section.Section_Title: section.count for section in result}
        if section_counts == {}:
            return {'message':'No books issued yet!'}, 404
        
        return section_counts, 200