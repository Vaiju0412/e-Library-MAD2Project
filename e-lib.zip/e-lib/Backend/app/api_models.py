from flask_restx import fields

from .imports import api

from .models import *

login_input = api.model("Login", {
    "user_id": fields.String(required=True, description="user_id"),
    "password": fields.String(required=True, description="password"), 
    }
)

signup_input = api.model("Sign-up", {
    "user_id": fields.String(required=True, description="user_id"),
    "password1": fields.String(required=True, description="password1"), 
    "firstName" : fields.String(required = True, description = "firstName"),
    "password2" : fields.String(required = True, description = "password2")
    }
)

section = api.model("addSection", {
    "title": fields.String(required = True, description = "title"),
    "descript": fields.String(description = "descript"),
}
)

user_book = api.model("User_Book",{
    "User_id": fields.Integer(),
    "Book_id": fields.Integer(),
    "Section_id": fields.Integer(),
    "Status": fields.String(),
    "expiration_period": fields.DateTime()
})


book = api.model("Book", {
    "Book_id": fields.Integer(),
    "Book_Name": fields.String(),
    "Author": fields.String(),
    "Synopsis": fields.String(),
    "Content": fields.String(), 
    "Requested": fields.Boolean(),
    "Issued": fields.Boolean(),
    "Rejected": fields.Boolean(),
    "Rejected": fields.Boolean(),
    "Status": fields.String(attribute='user_book_status')
})

getSections = api.model("getSections", {
    "Section_id": fields.Integer(),
    "Section_Title": fields.String(),
    "Section_Descript": fields.String(),
    "books": fields.List(fields.Nested(book))

}
)

getSection = api.model("getSections", {
    "Section_id": fields.Integer(),
    "Section_Title": fields.String(),
    "Section_Descript": fields.String(),

}
)

addBook = api.model("addBook", {
    "book_name": fields.String(required = True, description = "book_name"),
    "author": fields.String(required = True, description = "author"),
    "content": fields.String(required = True, description = "content"),
    "synopsis": fields.String(required = True, description = "synopsis"),
}
)

editBook = api.model("editBook", {
    "Book_Name": fields.String(required = True, description = "Book_Name"),
    "Author": fields.String(required = True, description = "Author"),
    "Content": fields.String(required = True, description = "Content"),
    "Synopsis": fields.String(required = True, description = "Synopsis"),
}
)
fetchBook = api.model("fetchBook", {
    "Book_Name": fields.String(required = True, description = "Book_Name"),
    "Author": fields.String(required = True, description = "Author"),
    "Content": fields.String(required = True, description = "Content"),
    "Synopsis": fields.String(required = True, description = "Synopsis"),
}
)

requestAccess = api.model("requestAccess", {
    "duration": fields.String(),
    "value": fields.Integer(),
    "bookId": fields.Integer(),
})

user_book_model = api.model('UserBook', {
    'user_book_id': fields.Integer(),
    'User_id': fields.Integer(),
    'Book_id': fields.Integer(),
    'Section_id': fields.Integer(),
    'Status': fields.String(),
    'feedback': fields.String(),
    'expiration_period': fields.String()
})

feedback_model = api.model('Feedback', {
    "user_id": fields.String(description="User ID"),
    "feedback": fields.String(description="Feedback"),
})

viewDetails = api.model('viewDetails', {
    "Book_Name": fields.String(required=True, description="Book Name"),
    "Author": fields.String(required=True, description="Author"),
    "Synopsis": fields.String(required=True, description="Synopsis"),
    "Feedbacks": fields.List(fields.Nested(feedback_model), description="Feedback given by users")
})

viewBook = api.model('viewBook', {
    "Book_id": fields.Integer(required=True, description="Book Id"),
    "Book_Name": fields.String(required=True, description="Book Name"),
    "Author": fields.String(required=True, description="Author"),
    "Synopsis": fields.String(required=True, description="Synopsis"),
    "Content": fields.String(required=True, description="Content"),
})

returnBook = api.model('returnBook', {
    "feedback": fields.String(),
})

