from .imports import * 
from .views import *
from .models import *
from flask_cors import CORS
from flask import Flask


def create_app():
    app = Flask(__name__)
    CORS(app, resources = {r"/*": {"origins":"*"}})

    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
    app.config['JWT_SECRET_KEY'] = 'ns fdkjgvnkgsml'
    app.config['JWT_BLACKLIST_ENABLED'] = True
    app.config['JWT_BLACKLIST_TOKEN_CHECKS'] = ['access', 'refresh']
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = False

    api.init_app(app)
    db.init_app(app)    
    jwt.init_app(app)

    api.add_namespace(lib)
    api.add_namespace(usr)

    @jwt.user_identity_loader
    def user_identity_lookup(user):
        return {"id": user.id, "user_id": user.user_id, "role": user.role}
    
    @jwt.user_lookup_loader
    def user_lookup_callback(_jwt_header, jwt_data):
        identity = jwt_data["sub"]["user_id"]
        return User.query.filter_by(user_id=identity).first()
    
    @jwt.token_in_blocklist_loader
    def check_if_token_in_blacklist(jwt_header, jwt_payload):
        return jwt_payload['jti'] in blocklist
    
    @jwt.revoked_token_loader
    def revoked_token_callback(jwt_header, jwt_payload):
        return {'message': 'Token has been revoked'}, 401

    with app.app_context():
        db.create_all()


    return app
